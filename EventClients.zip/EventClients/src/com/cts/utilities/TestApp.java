package com.cts.utilities;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;

public class TestApp {
public static void main(String[] args)
{
	ClientConfig clientConfig = new DefaultClientConfig();
	Client client=Client.create(clientConfig);
	WebResource service = client.resource("http://localhost:7070/EventManagementService");
ClientResponse cresponse = 
    		service.path("rest").path("/ImageServices/GetData/123;eventName=training")
    		.type("text/plain")
    	    .get(ClientResponse.class); 
    System.out.println(cresponse.getCookies());
    System.out.println(cresponse);
    
}
}
