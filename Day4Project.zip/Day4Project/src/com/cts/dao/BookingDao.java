package com.cts.dao;


import java.util.List;
import java.util.Random;

import org.hibernate.Cache;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;

import com.cts.entities.Customer;
import com.cts.entities.Event;
import com.cts.entities.Location;
import com.cts.resources.HibernateUtil;
//HQL
public class BookingDao{
	
private SessionFactory factory;
private Session session;
private Location location;
private Customer customer;
private Event event;

private static boolean status;

public BookingDao()
{
	factory=HibernateUtil.GetFactory();
}
public long GetLocationCount()
{
	factory=HibernateUtil.GetFactory();
	session=factory.openSession();
	Query query=session.createQuery("select count(loc.locationName)from Location loc");//Count
	return (long)query.list().get(0);
	
	
}
public int GetMaxLocationId()
{
	factory=HibernateUtil.GetFactory();
	session=factory.openSession();
	Query query=session.createQuery("select max(loc.locationId)from Location loc");//max
	return (int)query.list().get(0);
	
	
}
public List<Location> SortLocation()
{
	factory=HibernateUtil.GetFactory();
	session=factory.openSession();
	Query query=session.createQuery("from Location loc order by loc.locationName desc");//orderby desc
	return query.list();
	
	
}

public List<Location> GetLocationByName(String name)
{
	factory=HibernateUtil.GetFactory();
	session=factory.openSession();
	/*Query query=session.createQuery("from Location where locationName=?");//where clause(parameterized)
*/	
	/*Query query=session.getNamedQuery("GetLocationByName");//namedquery
*/	
	Criteria criteria=session.createCriteria(Location.class);//criteria
	criteria.add(Restrictions.gt("locationId", 150));
	criteria.add(Restrictions.like("locationName","CTS%"));
	return criteria.list();
}




public int SecondListLocation()
{
	factory=HibernateUtil.GetFactory();
	session=factory.openSession();
	Query query=session.createQuery("select max(l.locationId)from Location l where l.locationId<(select max(loc.locationId)from Location loc");//Count
	return (int)query.list().get(0);
	
	
}



public boolean InsertLocations()
{
	boolean status=false;
	factory=HibernateUtil.GetFactory();
	session=factory.openSession();
	session.beginTransaction();
	Random random=new Random();
	Location location=null;
	try
	{
	for(int i=0;i<100;i++){
		location=new Location();
		location.setLocationName("CTS"+random.nextInt(1000));
		session.save(location);
		status=true;
		if(i%20==0){
			session.flush();
			session.clear();
		}
	}
	session.getTransaction().commit();
	status=true;
	}
	catch(HibernateException ex)
	{
		session.getTransaction().rollback();
	}
	return status;
}
public boolean TestSecondLevelCache()
{
	factory=HibernateUtil.GetFactory();
	session=factory.openSession();
	Location location=(Location)session.load(Location.class, 105);
	System.out.println("Check first level cache before Evict");
	System.out.println("Status of Object"+session.contains(location));
	session.evict(location);
	System.out.println("Check first level cache before Evict");
	System.out.println("Status of Object"+session.contains(location));
	Cache cache=factory.getCache();
	System.out.println("Checks Second level cache after Evict");
	System.out.println("Status of Object"+cache.containsEntity(Location.class, 105));
	return cache.containsEntity(Location.class,105);
	
}


public int InsertLocation(Location loc)
{
	location=loc;
	int pk=0;
	session=factory.openSession();
	session.beginTransaction();
	try
	{
		pk=(Integer) session.save(location);
		session.save(location);
		session.getTransaction().commit();
	}
	catch(HibernateException es)
	{
		session.getTransaction().rollback();
	}
	return pk;
}
public void InsertEvent(Event eve,int locationId)
{
event=eve;
session=factory.openSession();
Location result=(Location)session.get(Location.class, locationId);
session.beginTransaction();
try
{
	session.persist(event);
	event.setLocation(location);
	session.persist(event);
	session.getTransaction().commit();
	
}
catch(HibernateException es)
{
	session.getTransaction().rollback();
}
session.close();
}
public void InsertCustomer(Customer customer)
{
	
}
public static boolean AddLocation(Location location)
{
	SessionFactory factory=HibernateUtil.GetFactory();
	Session session=factory.openSession();
	session.beginTransaction();
	try
	{
		session.save(location);
		session.getTransaction().commit();
		status=true;
	}
	catch(HibernateException ec)
	{
		session.getTransaction().rollback();
	}
	session.close();
	return status;
}
public static List<Customer> getAll()
{
	SessionFactory factory=HibernateUtil.GetFactory();
	Session session=factory.openSession();
	return session.createQuery("from Location").list();
}


}
