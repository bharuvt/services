package com.cog.tests;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cog.dao.DaoManager;
import com.cog.entities.Address;
import com.cog.entities.Employee;
import com.cog.entities.Manager;
import com.cog.entities.Person;
//association with table/joined
public class PersonTest {
	private DaoManager dao;

	@Before
	public void setUp() throws Exception {
		dao=new DaoManager();
	}

	@After
	public void tearDown() throws Exception {
	}
/*
	@Test
	public void test() {
		//fail("Not yet implemented");
		Person person=new Person();
		person.setName("Bharathi");
		Address address=new Address();
		address.setStreetName("BharathidhasanStree");
		address.setCity("Chennai");
		address.setState("TamilNadu");
		assertTrue(dao.AddPerson(person,address));
	}*/
	@Test
	public void test() {
		//fail("Not yet implemented");
		for(Manager manager:dao.GetAll())
		{
			System.out.print(manager.getAadharCardNo()+"\t");
			System.out.print(manager.getName()+"\t");
			System.out.print(manager.getAddress().getStreetName()+"\t");
			System.out.print(manager.getAddress().getCity()+"\t");
			System.out.print(manager.getAddress().getState()+"\t");
			System.out.print(manager.getEmployeeNo()+"\t");
			System.out.print(manager.getProject()+"\t");
			System.out.print(manager.getLocation()+"\t");
			System.out.print(manager.getNoOfProjects()+"\t");
			System.out.print(manager.isLeaveApproval()+"\t");
		}
		/*Manager manager=new Manager();
		manager.setName("Bala");
		manager.setEmployeeNo(1);
		manager.setLeaveApproval(true);
		manager.setLocation("Chennai");
		manager.setNoOfProjects(4);
		manager.setProject("HSBC");
		Address address=new Address();
		address.setStreetName("BharathidasanStree");
		address.setCity("Chennai");
		address.setState("TamilNadu");
		assertTrue(dao.AddManager(manager,address));*/
	}

}
