//Dao
package com.cognizant.dao;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;



import java.io.Serializable;
import java.util.*;

import com.cognizant.entity.Room;
import com.cognizant.resources.HibernateUtil;

public class RoomManager {
	private SessionFactory factory;
	private Session session;
	public RoomManager()
	{
		factory=HibernateUtil.GetFactory();
	}
	public boolean AddRoom(Room room)
	{
		boolean status=false;
		factory=HibernateUtil.GetFactory();
		session = factory.openSession();
		session.beginTransaction();
		try
		{
			session.save(room);
			session.getTransaction().commit();
			status=true;
		}
		catch(HibernateException ex)
		{
			session.getTransaction().rollback();
		}
		session.close();
		return status;
	}
	public List<Room> GetAllRooms()
	{
		session=factory.openSession();
		Query query=session.createQuery("from Room");
		return query.list();//return session.createQuery("from Room").list;
	}
public boolean UpdateRoom(int roomNo)
{
	boolean status=false;
	session=factory.openSession();
	Room room=(Room)session.get(Room.class,roomNo);
	room.setCapacity(35);
	room.setSystem_Avl(false);
	session.beginTransaction();
	try
	{
		//session.update(room);
		session.getTransaction().commit();
		status=true;
	}
	catch(HibernateException hib)
	{
		session.getTransaction().rollback();
	}
	session.close();
	return status;
}
public boolean DeleteRoom(int roomNo)
{
	boolean status=false;
	session=factory.openSession();
	Room room=(Room)session.get(Room.class,roomNo);
	room.setCapacity(55);
	room.setSystem_Avl(false);
	session.beginTransaction();
	try
	{
		session.delete(room);
		session.getTransaction().commit();
		status=true;
	}
	catch(HibernateException hib)
	{
		session.getTransaction().rollback();
	}
	session.close();
	return status;
}
public boolean roomEvict_Clear(int roomNo1, int roomNo2)
{
	boolean status=false;
	session=factory.openSession();
	Room obj1=(Room)session.get(Room.class, roomNo1);
	Room obj2=(Room)session.get(Room.class, roomNo2);
	//Modify obj1 and obj2
	session.clear();
	session.beginTransaction();
	obj1.setCapacity(90);
	obj2.setCapacity(100);
	session.getTransaction().commit();
	session.close();
	return status;
}
public boolean SessionClose(int roomNo)
{
	boolean status=false;
	session=factory.openSession();
	Room room=(Room)session.get(Room.class,roomNo);
	session.beginTransaction();
	session.close();
	room.setCapacity(67);
	Session session1=factory.openSession();
	session.beginTransaction();
	Room room1=(Room)session1.get(Room.class,roomNo);
	session1.merge(room);
	session1.getTransaction().commit();
	status=true;
	return status;
}
}
