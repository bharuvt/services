package com.cts.utilities;

import org.hibernate.Cache;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.cts.entities.Location;
import com.cts.resources.HibernateUtil;

public class TestApp {//interceptors

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
SessionFactory factory=HibernateUtil.getSessionFactory();
Session session=factory.openSession();
/*System.out.println("retrieve from first level cache.....");
Location ctsmessage= (Location) session.load(Location.class, 2);
System.out.println(ctsmessage.getLocationName());
System.out.println("Before Clear"+session.contains(ctsmessage));
session.evict(ctsmessage);
System.out.println("After Clear"+session.contains(ctsmessage));
System.out.println("retrieve from second level cache.....");
Cache cache = factory.getCache();
System.out.println(cache.containsEntity(Location.class, 2));
ctsmessage=(Location) session.load(Location.class, 2);
System.out.println(ctsmessage.getLocationName());*/
session.beginTransaction();//saviing...
try
{
	Location location=new Location();
	location.setLocationName("SEZ");
	session.save(location);
	session.getTransaction().commit();
}
catch(HibernateException ex)
{
	session.getTransaction().rollback();
}
session.close();
	}

}
