package com.cts.services;

import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;

import com.cts.entities.Message;

@Path("/ProductService")
public class FProductService {

	@POST
	@Path("/AddProduct")
	public Response AddProduct(@FormParam("productId")int Id,@FormParam("name") String Name)
	{
		Message message=new Message();
		if((Id>0)&&(Name!=null))
				{
			System.out.println("productId"+Id);
				System.out.println("productName"+Name);
			message.setStatus("Received Data="+Id+"\t"+Name);
				}
			
		return Response.status(200).header("Access-Control-Allow-Origin", "*")
				.header("Acess-Control-Allow-Headers", "origin,content-type,accept,authorization")
				.header("Access-Control-Allow-Credntials", "true")
				.header("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE,OPTIONS,HEAD")
				.header("Access-Control-Max-Age", "1209600").entity(message)
	            .build();
	}
}
