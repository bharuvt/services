package com.cts.utilities;

import com.cts.dao.BookingDao;
import com.cts.entities.Location;

public class TestApp {
public static void main(String[] args)
{
	BookingDao dao=new BookingDao();
	/*System.out.println(dao.GetMaxLocationId());*/
	for(Location location:dao.GetLocationByName("CTS"))
	{
		System.out.println(location.getLocationName());
	}
	/*System.out.println(dao.SecondListLocation());*/
	/*Location loc=dao.GetLocationByName("CTS58");
	System.out.println(loc.getLocationId());*/
}
}
