package com.cog.tests;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cog.dao.DaoManager;
import com.cog.entities.CreditCard;
import com.cog.entities.Payment;

public class PaymentTest {
	private DaoManager dao;

	@Before
	
	public void setUp() throws Exception {
	dao=new DaoManager();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void PaymentObjTest() {
		//fail("Not yet implemented");
		Payment payment=new Payment();
		payment.setCustomerId(101);
		payment.setAmount(10000);
		payment.setDOT(new Date(2016,1,7));
		assertTrue(dao.AddPayment(payment));
		
	}
	/*@Test
	public void CreditCardObjTest() {
		//fail("Not yet implemented");
		CreditCard payment=new CreditCard();
		payment.setCustomerId(101);
		payment.setAmount(10000);
		payment.setDOT(new Date(2016,1,7));
		payment.setCreditcardNo(456321);
		payment.setCvv(123654);
		payment.setcName("VISA");
		payment.setcExpiryDate(new Date(29,1,1));
		payment.setEMI(false);
		assertTrue(dao.AddPayment(payment));
		
	}*/
}
