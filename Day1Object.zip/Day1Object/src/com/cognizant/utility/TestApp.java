//TestApp mai method
package com.cognizant.utility;

import java.util.Scanner;

import com.cognizant.dao.EventManager;
import com.cognizant.dao.RoomManager;
import com.cognizant.entity.Event;
import com.cognizant.entity.EventKey;
import com.cognizant.entity.Room;

public class TestApp {
	public static void main(String[] args)
	{/*
		RoomManager roomManager=new RoomManager();
		Room room=new Room();
		room.setCapacity(27);
		room.setLocation("ASV Sun Tech");
		room.setProjector_Avl(true);
		room.setSystem_Avl(true);
		roomManager.AddRoom(room);
		System.out.println("Record Added");
		for(Room room:roomManager.GetAllRooms())
		{
			System.out.print(room.getRoomNo()+"\t");
			System.out.print(room.getCapacity());
		}
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter Room No1");
		int roomNo1=scanner.nextInt();
		roomManager.SessionClose(roomNo1);
		System.out.println("Enter Room No2");
		int roomNo2=scanner.nextInt();
		roomManager.roomEvict_Clear(roomNo1, roomNo2);
		//roomManager.UpdateRoom(roomNo);
		//roomManager.DeleteRoom(roomNo);
	
		}*/
		EventManager eventmanager=new EventManager();
		EventKey eventkey=new EventKey();
		eventkey.setEventId(1);
		eventkey.setTrainerId(249);
		Event event=new Event();
		event.setEventId(eventkey);
		event.setDuration(5);
		event.setEventName("HibernateTraining");
		event.setLocation("Chennai");
		eventmanager.AddEvent(event);
	}
}
