package com.cts.services;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.cts.dao.BookingDao;
import com.cts.entities.Customer;
import com.cts.entities.Location;
import com.cts.entities.Message;


@Path("/LocationService")
public class LocationService {
	@Path("/AddLocation")
	@POST
	@Consumes({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	public Response AddLocationService(Location loc)
	{
	boolean status=BookingDao.AddLocation(loc);
	Message message=new Message();
	if(status)
	{
		message.setStatus("Record Added");
	}
	return Response.status(200).header("Access-Control-Allow-Origin", "*")
			.header("Acess-Control-Allow-Headers", "origin,content-type,accept,authorization")
			.header("Access-Control-Allow-Credntials", "true")
			.header("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE,OPTIONS,HEAD")
			.header("Access-Control-Max-Age", "1209600").entity(message)
            .build();
}

@Path("/GetLocation")
@GET
@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
public Response getCustomers()
{
	//Coverting collection to json
	GenericEntity<List<Customer>> genentity=new GenericEntity<List<Customer>>(BookingDao.getAll()){};
	return Response.status(200).header("Access-Control-Allow-Origin", "*")
			.header("Acess-Control-Allow-Headers", "origin,content-type,accept,authorization")
			.header("Access-Control-Allow-Credntials", "true")
			.header("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE,OPTIONS,HEAD")
			.header("Access-Control-Max-Age", "1209600").entity(genentity)
            .build();
}
}
