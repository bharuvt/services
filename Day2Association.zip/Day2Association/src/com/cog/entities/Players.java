package com.cog.entities;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
//bidirectinal manytoone
@Entity
@Table(name="Player")
public class Players {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="PlayerId")
	private int playerId;
	@Column(name="PlayerName")
	private String playerName;
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="Team_ID",nullable=false)
	private Team team;
	public int getPlayerId() {
		return playerId;
	}
	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}
	public String getPlayerName() {
		return playerName;
	}
	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}
	public Team getTeam() {
		return team;
	}
	public void setTeam(Team team) {
		this.team = team;
	}
	

}
