package com.cognizant.entities;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;


@Entity
@Table(name="Event")
public class Event {
@EmbeddedId
private EventKey eventid;
@Column(name="Event_Name")
private String eventName;
@Column(name="Duration")
private int duration;
@Column(name="Location")
private String location;
public EventKey getEventid() {
return eventid;
}
public void setEventid(EventKey eventid) {
this.eventid = eventid;
}
public String getEventName() {
return eventName;
}
public void setEventName(String eventName) {
this.eventName = eventName;
}
public int getDuration() {
return duration;
}
public void setDuration(int duration) {
this.duration = duration;
}
public String getLocation() {
return location;
}
public void setLocation(String location) {
this.location = location;
}

}
